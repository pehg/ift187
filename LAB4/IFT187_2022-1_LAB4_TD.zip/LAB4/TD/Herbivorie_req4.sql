/*
-- =========================================================================== A
Activité : IFT187
Trimestre : 2022-1
Composant : Herbivorie_req3.sql
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 9.4-14.1
Responsable : Luc.Lavoie@USherbrooke.ca
Version : 0.2.0a
Statut : en cours de développement
-- =========================================================================== A
*/

/*
-- =========================================================================== B
Quelques requêtes de groupement, de quantification et d'ordonnancement.

Notes de mise en oeuvre
(a) aucune.
-- =========================================================================== B
*/

-- Y1.
-- Ajouter les types et les tables requises pour consigner les conditions météorologiques quotidiennes.
-- Pour chaque journée consignée, donner la température minimale, la température maximale,
-- la vitesse minimale des vents, la vitesse maximale, la pression atmosphérique minimale,
-- la pression maximale, le taux d’humidité minimal, le taux maximal, le nombre de millimètres
-- de précipitation et la nature de la précipitation, ainsi que la durée cumulative d’ensoleillement.
-- Le cas échéant, choisir les unités appropriées.


-- Y2.
-- Ajouter des données météorologiques vraisemblables et représentatives pour le mois de juin 2016.
-- À partir de la table CarnetMeteo, alimenter les tables créées en Y1 en faisant les vérifications requises.
-- Définir les fonctions requises pour ce faire. N’insérer que les données valides et intègres.
-- Proposer un jeu de données qui illustre l’adéquation de votre alimentation.


-- Y3.
-- Définir une vue donnant les conditions météorologiques complètes hors précipitation.
-- Maintenir les mêmes identifiants d’attributs qu’en Y1.


-- Y4.
-- Définir l’assertion requise de la table Taux.
-- Dans le script de création, on suggère de vérifier que les intervalles associés aux catégories
-- ne se chevauchent pas.
-- Mettre en oeuvre l’assertion requise à l’aide d’un automatisme (trigger).


-- Y5.
-- Modifier la table ObsFloraison.
-- Celle-ci ne doit refléter que la date de la première constatation que le plant est porteur d’une
-- fleur ou d’un fruit, en conséquence il faut retirer l’attribut fleur, modifier la contrainte
-- de clé candidate et épurer les données.
-- Faire cette opération sans perdre les données pertinentes à ‘aide, notamment de commandes ALTER.


-- Y6.
-- Modifier le nom d’un attribut (ou refuser de le faire en donnant une argumentation motivée).
-- Changer le nom de l’attribut « peup » de la table Peuplement pour « peuplement ».


-- Y7
-- Bonus : Définir les assertions requises de la table Placette.
-- Dans le script de création, on suggère de vérifier la cohérence des observations
-- relatives aux obstructions latérales.
-- Mettre en oeuvre l’assertion requise à l’aide d’automatismes (trigger).


/*
-- =========================================================================== Z
Contributeurs :
  (CK) Christina.Khnaisser@USherbrooke.ca
  (LL) Luc.Lavoie@USherbrooke.ca

Adresse, droits d'auteur et copyright :
  Groupe Metis
  Département d'informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0)]

Tâches projetées :
  * ...

Tâches réalisées :
2017-10-02 (LL) : Création
  * Version initiale.

Références :
[ddv] http://info.usherbrooke.ca/llavoie/enseignement/Exemples/Herbivorie/Herbivorie_DDV.pdf
[mod] http://info.usherbrooke.ca/llavoie/enseignement/Modules/
-- -----------------------------------------------------------------------------
-- fin de Herbivorie_req4.sql
-- =========================================================================== Z
*/
