/*
-- =========================================================================== A
Activité : IFT187
Trimestre : 2022-1
Composant : Meteo_req4.sql
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 9.4-14.1
Responsable : Luc.Lavoie@USherbrooke.ca
Version : 0.1.1a
Statut : base de développement
Documentation : Herbivorie_ELT_SCL.adoc
-- =========================================================================== A
*/

--
-- == Test minimaliste de l'importation des carnets météorologiques dans la base de données.
--

-- Vider les tables du contenu des précédents essais
delete from ObsTemperature ;
delete from ObsHumidite ;
delete from ObsPrecipitations ;
delete from ObsVents ;
delete from ObsPression ;
delete from CarnetMeteo ;

-- Ajouter les données au carnet météorologique (remarquons la conversion implicite des données numériques!!!)
insert into CarnetMeteo values
  (10, 14, 18, 24, 0, 'P', 4, 20, 1028, 1030, '2016-05-04', 'départ'),
  (10, 14, 18, 24, null, null, 4, 20, 1028, 1030, '2016-05-05', 'comme hier'),
  (10, 14, 18, 24, null, null, 4, 20, 1028, 1030, '2015-05-05', 'refus d'),
  (10, 65, -2, 24, 10, 'K', 4, 2000, 1028, 2000, '2016-07-05', 'refus m'),
  (12, 15, 24, 30, 1, 'P', 8, 10, 1026, 1028, '2016-05-06', 'fin');

-- Faire l'importation
call Meteo_ELT () ;

-- Fin