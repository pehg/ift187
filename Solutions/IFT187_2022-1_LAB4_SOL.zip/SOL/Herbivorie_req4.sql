/*
-- =========================================================================== A
Activité : IFT187
Trimestre : 2022-1
Composant : Herbivorie_req4.sql
Encodage : UTF-8, sans BOM; fin de ligne Unix (LF)
Plateforme : PostgreSQL 9.4-14.1
Responsable : Luc.Lavoie@USherbrooke.ca
Version : 0.2.0a
Statut : en cours de développement
-- =========================================================================== A
*/

/*
-- =========================================================================== B
Quelques requêtes de groupement, de quantification et d'ordonnancement.

Notes de mise en oeuvre
(a) aucune.
-- =========================================================================== B
*/

--
-- Y3.
-- Définir une vue donnant les conditions météorologiques complètes hors précipitation.
-- Maintenir les mêmes identifiants d’attributs qu’en Y1 (voir Meteo_cre.sql).
-- Clarification :
--   Que signifie complète ?
--   Que faire si, pour une date donnée, certaines mesures sont absentes ?
--   Toutes les mesures doivent être présentes pour qu'un tuple soit retenu.
--
CREATE VIEW Meteo_HP
(
  date      ,   -- date de la prise de donnée
  note      ,   -- note supplémentaire à propos des conditions du jour
  temp_min  ,   -- la température minimale,
  temp_max  ,   -- la température maximale,
  hum_min   ,   -- le taux d’humidité absolue minimal (en pourcentage),
  hum_max   ,   -- le taux d’humidité absolue maximal (en pourcentage),
  vent_min  ,   -- la vitesse minimale des vents (en km/h),
  vent_max  ,   -- la vitesse maximale des vents (en km/h),
  pres_min  ,   -- la pression atmosphérique minimale (en hPa),
  pres_max      -- la pression atmosphérique maximale (en hPa),
) AS
  SELECT *
    FROM ObsTemperature
      NATURAL JOIN ObsHumidite
      NATURAL JOIN ObsVents
      NATURAL JOIN ObsPression ;

--
-- Y4.
-- Retirer les données météorologiques du 17 au 19 juin si la température minimale
-- rapportée est en deçà de 4 C (le capteur était défectueux).
-- Utiliser l’instruction DELETE.
-- Clarification :
--    Seules les données de températures doivent être détruites.
--    Seule l'année 2016 est concernée.
--
DELETE FROM ObsTemperature
WHERE (date BETWEEN '2016-06-17' AND '2016-06-17') AND  (temp_min < 4)

--
-- Y5.
-- Augmenter les températures rapportées de 10 % entre le 20 et 30 juin
-- (le capteur était mal calibré).
-- Utiliser l’instruction UPDATE.
-- Clarification :
--    Seule l'année 2016 est concernée.
--    L'augmentation est relative à la valeur absolue de la temperature.
--
UPDATE ObsTemperature
SET temp_min = temp_min + 0.1* abs(temp_min), temp_max = temp_max + 0.1* abs(temp_max)
WHERE (date BETWEEN '2016-06-20' AND '2016-06-30')

/*
-- =========================================================================== Z
Contributeurs :
  (CK) Christina.Khnaisser@USherbrooke.ca
  (LL) Luc.Lavoie@USherbrooke.ca

Adresse, droits d'auteur et copyright :
  Groupe Metis
  Département d'informatique
  Faculté des sciences
  Université de Sherbrooke
  Sherbrooke (Québec)  J1K 2R1
  Canada
  http://info.usherbrooke.ca/llavoie/
  [CC-BY-NC-4.0 (http://creativecommons.org/licenses/by-nc/4.0)]

Tâches projetées :
  * ...

Tâches réalisées :
2017-10-02 (LL) : Création
  * Version initiale.

Références :
[ddv] http://info.usherbrooke.ca/llavoie/enseignement/Exemples/Herbivorie/Herbivorie_DDV.pdf
[mod] http://info.usherbrooke.ca/llavoie/enseignement/Modules/
-- -----------------------------------------------------------------------------
-- fin de Herbivorie_req4.sql
-- =========================================================================== Z
*/
